

import pygame
import time
import random
from pygame import mixer


# set up pygame window
WIDTH = 1369
HEIGHT = 700

FPS = 30
gone = {}
G = {}
G_1 = {}
pos = []
# Define colours
WHITE = (140, 255, 255)
GREEN = (0, 255, 0,)
BLUE = (0, 0, 200)
SCREEN = (0, 150, 255)
BRIGHT_BLUE = (0, 0, 255)
YELLOW = (255 ,220 ,0)
BRIGHT_YELLOW = (255, 255, 51)
BLACK = (0, 0, 0)
RED = (200, 0, 0)
BRIGHT_RED = (255, 0, 0)
BRIGHT_PINK = (255, 51, 153)
PINK = (255, 0, 127)
PURPLE = (75,0,130)
BRIGHT_PURPLE = (75,50,130)
ORANGE = (255,69,0)
BRIGHT_ORANGE = (255,119,0)
# Define helper functions:

color_lst = [RED, BLUE, BRIGHT_BLUE, BRIGHT_RED, PURPLE]
maze_color = random.choice(color_lst)
maze_color = WHITE

s = 0
t = 0
choice = ""

# initalise Pygame
pygame.init()
pygame.mixer.init()
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Python Maze Generator")
clock = pygame.time.Clock()

# mixer.music.load("journey.wav")
# mixer.music.play(-1)

# setup maze variables
x = 0                    
y = 0                    
w = 17                 
grid = []
visited = []
stack = []
solution = {}

G = {}

def renew():
    x = 0
    y = 0
    w = 0
    grid = []
    visited = []
    stack = []
    solution = []
    G = {}
    pos = []
    s = 0
    t = 0
    choice = ""
    edges = {}
    G_1 = {}
    # gone = []

# build the grid
def build_grid_1(x, y, w):
    for i in range(1,31):
        x = 17                                                         
        y = y + 17                                                        
        for j in range(1, 51):
            pygame.draw.line(screen, WHITE, [x, y], [x + w, y])           
            pygame.draw.line(screen, WHITE, [x + w, y], [x + w, y + w])   
            pygame.draw.line(screen, WHITE, [x + w, y + w], [x, y + w])   
            pygame.draw.line(screen, WHITE, [x, y + w], [x, y])           
            grid.append((x,y))                                            
            x = x + 17
    # time.sleep(10000)                                                   
    screen.fill(BLACK)
edges = {}

def display_girl(x, y, teacher):
    screen.blit(teacher, (x, y))

def display_time(seconds, minutes, time, x, y):
    
    pygame.draw.rect(screen, BLACK, (900, 75, 1250, 100), 0)
    pygame.display.update()
    font = pygame.font.Font('freesansbold.ttf', 80)
    if seconds <= 9:
        time = font.render(str(0) + str(minutes) + ":" + str(0) + str(seconds), True, (255, 255, 255))
    else:
        time = font.render(str(0) + str(minutes) + " " + str(seconds), True, (255, 255, 255))
    screen.blit(time, (x, y))
    pygame.display.update()

def display_thought(x, y, thought):
    screen.blit(thought, (x, y))

teacher = pygame.image.load("teacher.png")
pygame.display.set_icon(teacher)

thought = pygame.image.load("thoughts.png")
pygame.display.set_icon(thought)

arrow = pygame.image.load("arrows.png")
pygame.display.set_icon(arrow)


def display_arrow(x, y, arrow):
    screen.blit(arrow, (x, y))

maze = pygame.image.load("maze2.png")
pygame.display.set_icon(maze)

def display_maze(maze, x, y):
    screen.blit(maze, (x, y))
    
def display_tree(x, y, tree):
    screen.blit(tree, (x, y))

def display_volume(x, y, volume):
    screen.blit(volume, (x, y))

def build_grid_2(x, y, w):
    for i in range(1,31):
        x = 17                                                           
        y = y + 17                                                       
        for j in range(1, 51):
            pygame.draw.line(screen, WHITE, [x, y], [x + w, y])           
            pygame.draw.line(screen, WHITE, [x + w, y], [x + w, y + w])   
            pygame.draw.line(screen, WHITE, [x + w, y + w], [x, y + w])   
            pygame.draw.line(screen, WHITE, [x, y + w], [x, y])           
            grid.append((x,y))                                           
            edges[(x, y)] = random.randint(0, 1000)
            x = x + 17
    screen.fill(BLACK)

tree = pygame.image.load("tuscany.png")
pygame.display.set_icon(tree)


volume = pygame.image.load("volume.png")
pygame.display.set_icon(volume)
path = []

def build_grid_3(x, y, w):
    for i in range(1,31):
        x = 17                                                           
        y = y + 17                                                       
        for j in range(1, 51):
            pygame.draw.line(screen, WHITE, [x, y], [x + w, y])           
            pygame.draw.line(screen, WHITE, [x + w, y], [x + w, y + w])   
            pygame.draw.line(screen, WHITE, [x + w, y + w], [x, y + w])     
            pygame.draw.line(screen, WHITE, [x, y + w], [x, y])           
            grid.append((x,y))
            num = random.randint(0, 1000)                                        
            path.append((num, x, y))
            x = x + 17
    screen.fill(BLACK)
    display_girl(500, 400, teacher)
    path.sort()



def build_grid_4(x, y, w):
    for i in range(1,31):
        x = 17                                                         
        y = y + 17                                                       
        for j in range(1, 51):
            pygame.draw.line(screen, WHITE, [x, y], [x + w, y])           
            pygame.draw.line(screen, WHITE, [x + w, y], [x + w, y + w])   
            pygame.draw.line(screen, WHITE, [x + w, y + w], [x, y + w])   
            pygame.draw.line(screen, WHITE, [x, y + w], [x, y])           
            grid.append((x,y))                                           
            edges[(x, y)] = random.randint(0, 1000)
            x = x + 17
    screen.fill(BLACK)
    # screen.fill(BLACK)
    # teacher = pygame.image.load("teacher.png")
    # pygame.display.set_icon(teacher)
    # display_girl(500, 400, teacher)

def selection_sort(lst):
    for i in range(len(lst)):
        minimum = i
        for j in range(i, len(lst)):
            if lst[minimum][2] > lst[j][2]:
                lst[j], lst[minimum] = lst[minimum], lst[j]
    return lst


def push_up(x, y, color):
    pygame.draw.rect(screen, color, (x+3 , y - w  +3, 12, 26), 0)
    # pygame.draw.rect(screen, color, (x+2 , y - w  +2, 14, 28), 0)        
    pygame.display.update()                                              


def push_down(x, y, color):
    pygame.draw.rect(screen, color, (x +  3, y + 3, 12, 29), 0)
    # pygame.draw.rect(screen, color, (x +  2, y + 2, 14, 31), 0)
    pygame.display.update()


def push_left(x, y, color):
    pygame.draw.rect(screen, color, (x - w+3 , y +3, 29, 12), 0)
    pygame.display.update()


def push_right(x, y, color):
    pygame.draw.rect(screen, color, (x +3, y +3, 29, 12), 0)
    pygame.display.update()


def single_cell(x, y, color):
    pygame.draw.rect(screen, color, (x +3, y +3, 12, 12), 0)          
    pygame.display.update()

def draw_vertical(x, y):
    pygame.draw.rect(screen, GREEN, (x +1, 20, 18, 400), 0) 
    pygame.display.update()

def draw_horizontal(x, y):
    pygame.draw.rect(screen, GREEN, (20, y+1, 400, 18), 0) 
    pygame.display.update()

def backtracking_cell(x, y, maze_color):
    pygame.draw.rect(screen, maze_color, (x +3, y +3, 12, 12), 0)        
    pygame.display.update()                                        

# def backtracking_cell_1(x, y, maze_color):
#     pygame.draw.rect(screen, maze_color, (x , y +1, 17, 17), 0)        
#     pygame.display.update()

def solution_cell(x,y):
    pygame.draw.rect(screen, PURPLE, (x+8, y+8, 5, 5), 0)             
    pygame.display.update()                                        

def find_node(dis_set, node):
    for j in range(len(dis_set)):
        if node in dis_set[j]:
            return j

def carve_out_maze_1(x,y, maze_color):
    single_cell(x, y, GREEN)                                              
    stack.append((x,y))                                            
    visited.append((x,y))
    w = 17                                     
    while len(stack) > 0:
        if (x, y) not in G:
            G[(x, y)] = []                                           
        time.sleep(0.02)                                       
        cell = []                                                  
        if (x + w, y) not in visited and (x + w, y) in grid:       
            cell.append("right")                                   

        if (x - w, y) not in visited and (x - w, y) in grid:       
            cell.append("left")

        if (x , y + w) not in visited and (x , y + w) in grid:     
            cell.append("down")

        if (x, y - w) not in visited and (x , y - w) in grid:      
            cell.append("up")

        if len(cell) > 0:                                          
            cell_chosen = (random.choice(cell))                    

            if cell_chosen == "right":                             
                push_right(x, y, maze_color)                                   
                solution[(x + w, y)] = x, y
                G[(x, y)].append((x+w, y))                        
                x = x + w                                          
                visited.append((x, y))                              
                stack.append((x, y))                                

            elif cell_chosen == "left":
                push_left(x, y, maze_color)
                solution[(x - w, y)] = x, y
                G[(x, y)].append((x-w, y))
                x = x - w
                visited.append((x, y))
                stack.append((x, y))

            elif cell_chosen == "down":
                push_down(x, y, maze_color)
                solution[(x , y + w)] = x, y
                G[(x, y)].append((x, y+w))
                y = y + w
                visited.append((x, y))
                stack.append((x, y))

            elif cell_chosen == "up":
                push_up(x, y, maze_color)
                solution[(x , y - w)] = x, y
                G[(x, y)].append((x, y-w))
                y = y - w
                visited.append((x, y))
                stack.append((x, y))
        else:
            x, y = stack.pop()                                    
            single_cell(x, y, GREEN)                                     
            time.sleep(.01)                                       
            backtracking_cell(x, y, maze_color)          






def carve_out_maze_2(x,y, stack, maze_color):
    x, y = 17, 17
    a, b = x, y
    stack.append((x,y))                                            
    visited.append((x,y))
    w = 17
    for i in grid:
        x, y = i
        G[(x, y)] = []
        if (x + w, y) in grid:
            G[(x, y)].append(((x+w, y), abs(edges[(x, y)] - edges[(x+w, y)]), "right"))
           
        if (x - w, y) in grid:
            G[(x, y)].append(((x-w, y), abs(edges[(x, y)] - edges[(x-w, y)]), "left"))
            
        if (x , y + w) in grid:
            G[(x, y)].append(((x, y+w), abs(edges[(x, y)] - edges[(x, y+w)]), "down"))
            
        if (x , y - w) in grid:
            G[(x, y)].append(((x, y-w), abs(edges[(x, y)] - edges[(x, y-w)]), "up"))
            
    x, y = a, b
    gone, p_queue, nodes = [(x, y)], [], [i for i in G ]
    G_1[(x, y)] = []
    p = (x, y)
    t = []
    # while len(gone) <= len(nodes):
    check = False
    while not check:
        time.sleep(0.000001)
        for i in G[(p)]:
            if i[0] not in gone and i[0] not in t:
    
                p_queue.append((i[1], i[0], p, i[2]))  #(dsitance, ele, parent, direction)
                t.append(i[0])
        p_queue.sort()
        
        a = p_queue.pop(0)
        G_1[a[2]].append(a[1])
        cell_chosen = a[3]
        x, y = a[2]
        if (x, y) not in G_1:
            G_1[(x, y)] = []
        if cell_chosen == "right":                             
            push_right(x, y, maze_color)                                   
            solution[(x + w, y)] = x, y
            # G_1[(x, y)].append((x + w, y)) 
            x = x + w    
            gone.append((x, y))
            G_1[(x, y)] = []                          
                                    
        elif cell_chosen == "left":
            push_left(x, y, maze_color)
            solution[(x - w, y)] = x, y
            # G_1[(x, y)].append((x - w, y))
            x = x - w
            gone.append((x, y))
            G_1[(x, y)] = []
            

        elif cell_chosen == "down":
            push_down(x, y, maze_color)
            solution[(x , y + w)] = x, y
            # G_1[(x, y)].append((x, y + w))
            y = y + w
            gone.append((x , y))
            G_1[(x, y)] = []


        elif cell_chosen == "up":
            push_up(x, y, maze_color)
            solution[(x , y - w)] = x, y
            # G_1[(x, y)].append((x, y - w))
            y = y - w
            gone.append((x , y))
            G_1[(x, y)] = []
            
        p = (x, y)
        if not p_queue:
            check = True
    
        
    
            
def is_empty(stack):
    return len(stack) == 0


def carve_out_maze_3(x,y, maze_color):
    num = 0
    single_cell(x, y, GREEN)                                              
    stack.append((x,y))                                            
    visited.append((x,y))
    w = 17                                       
    while not is_empty(stack):
        time.sleep(0.03)
        trash = stack.pop()                                                                                                         
        cell = []
        if (x, y) not in G:
            G[(x, y)] = []                                                  
        if (x + w, y) not in visited and (x + w, y) in grid:       
            cell.append("right")                                   

        if (x - w, y) not in visited and (x - w, y) in grid:       
            cell.append("left")

        if (x , y + w) not in visited and (x , y + w) in grid:     
            cell.append("down")

        if (x, y - w) not in visited and (x , y - w) in grid:      
            cell.append("up")

        if len(cell) > 0:                                          
            cell_chosen = (random.choice(cell))                    

            if cell_chosen == "right":                             
                push_right(x, y, maze_color)                                   
                solution[(x + w, y)] = x, y
                G[(x, y)].append((x + w, y))                        
                x = x + w                                          
                visited.append((x, y))                              
                stack.append((x, y))                                

            elif cell_chosen == "left":
                push_left(x, y, maze_color)
                solution[(x - w, y)] = x, y
                G[(x, y)].append((x - w, y)) 
                x = x - w
                visited.append((x, y))
                stack.append((x, y))

            elif cell_chosen == "down":
                push_down(x, y, maze_color)
                solution[(x , y + w)] = x, y
                G[(x, y)].append((x, y+w)) 
                y = y + w
                visited.append((x, y))
                stack.append((x, y))

            elif cell_chosen == "up":
                push_up(x, y, maze_color)
                solution[(x , y - w)] = x, y
                G[(x, y)].append((x, y - w)) 
                y = y - w
                visited.append((x, y))
                stack.append((x, y))
        else:
            while num < len(grid):
                x, y = grid[num]
                single_cell(x, y, GREEN)
                single_cell(x, y, maze_color)
                if (x, y) in visited:
                    if (x, y) not in G:
                        G[(x, y)] = []                               
                    if (x + w, y) not in visited and (x + w, y) in grid:       
                        cell.append("right")                                   

                    if (x - w, y) not in visited and (x - w, y) in grid:       
                        cell.append("left")

                    if (x , y + w) not in visited and (x , y + w) in grid:     
                        cell.append("down")

                    if (x, y - w) not in visited and (x , y - w) in grid:      
                        cell.append("up")
                if len(cell) == 0:
                    num += 1
                    continue
                else:                                     
                    cell_chosen = (random.choice(cell)) 
                    if cell_chosen == "right":
                        single_cell(x, y, RED)                  
                        push_right(x, y, maze_color)                                   
                        solution[(x + w, y)] = x, y
                        G[(x, y)].append((x + w, y))                        
                        x = x + w                                          
                        visited.append((x, y))                              
                        stack.append((x, y))
                        num += 1                               

                    elif cell_chosen == "left":
                        push_left(x, y, maze_color)
                        solution[(x - w, y)] = x, y
                        G[(x, y)].append((x - w, y)) 
                        x = x - w
                        visited.append((x, y))
                        stack.append((x, y))
                        num += 1

                    elif cell_chosen == "down":
                        push_down(x, y, maze_color)
                        solution[(x , y + w)] = x, y
                        G[(x, y)].append((x, y+w))
                        y = y + w
                        visited.append((x, y))
                        stack.append((x, y))
                        num += 1

                    elif cell_chosen == "up":
                        push_up(x, y, maze_color)
                        solution[(x , y - w)] = x, y
                        G[(x, y)].append((x, y - w)) 
                        y = y - w
                        visited.append((x, y))
                        stack.append((x, y))
                        num += 1
                break
    
            

def carve_out_maze_4(x,y,edges, nodes, maze_color):                                     
    stack.append((x,y))                                            
    visited.append((x,y))
    w = 17                              
    while len(stack) > 0:
        if (x, y) not in G:
            G[(x, y)] = []                                                                                   
        cell = []                                                  
        if (x + w, y) not in visited and (x + w, y) in grid:       
            cell.append("right")                                   
        if (x - w, y) not in visited and (x - w, y) in grid:       
            cell.append("left")
        if (x , y + w) not in visited and (x , y + w) in grid:     
            cell.append("down")
        if (x, y - w) not in visited and (x , y - w) in grid:      
            cell.append("up")
        if len(cell) > 0:                                          
            cell_chosen = (random.choice(cell))                    
            if cell_chosen == "right":                                                               
                G[(x, y)].append(((x+w, y), abs(edges[(x, y)] - edges[(x+w, y)]), "right"))                        
                x = x + w                                          
                visited.append((x, y))                              
                stack.append((x, y))                                
            elif cell_chosen == "left":
                G[(x, y)].append(((x-w, y), abs(edges[(x, y)] - edges[(x-w, y)]), "left"))
                x = x - w
                visited.append((x, y))
                stack.append((x, y))
            elif cell_chosen == "down":
                G[(x, y)].append(((x, y+w), abs(edges[(x, y)] - edges[(x, y+w)]), "down"))
                y = y + w
                visited.append((x, y))
                stack.append((x, y))
            elif cell_chosen == "up":
                G[(x, y)].append(((x, y-w), abs(edges[(x, y)] - edges[(x, y-w)]), "up"))
                y = y - w
                visited.append((x, y))
                stack.append((x, y))
        else:
            x, y = stack.pop()
    edges = []
    for i in G:
        for j in G[i]:
            edges.append((i, j[0], j[1], j[2]))
    dis_set, path, gone = [[i] for i in nodes], selection_sort(edges), []
    for i in path:
        time.sleep(0.01)                                        
        a, b = find_node(dis_set, i[0]), find_node(dis_set, i[1])
        if a != b:
            dis_set.append(dis_set[a] + dis_set[b])
            x, y = i[0]
            time.sleep(.001) 
            if i[3] == "right":
                push_right(x, y, maze_color)                                   
                solution[(x + w, y)] = x, y                                                             
            elif i[3] == "left":
                push_left(x, y, maze_color)                                   
                solution[(x - w, y)] = x, y                                                             
            elif i[3] == "down":              
                push_down(x, y, maze_color)                                   
                solution[(x, y+w)] = x, y                                                                          
            elif i[3] == "up":               
                push_up(x, y, maze_color)                                   
                solution[(x, y-w)] = x, y                                                             
                
            c, d = dis_set[a], dis_set[b]
            dis_set.remove(c); dis_set.remove(d); gone.append(i)
    gone.sort()
    
   

def carve_out_maze_5(x, y, maze_color):
    single_cell(x, y, GREEN)
    visited = [] 
    choice = "" 
    w = 17
                                                                                                                             
    for i in grid:
        time.sleep(0.05)
        cell = []
        x, y = i
        single_cell(x, y, GREEN)
        time.sleep(0.01)
        single_cell(x, y, maze_color)
        visited.append(i)
        if x == 850 and y == 17:
            visited = []
            continue
        else:
            time.sleep(0.01)
            visited.append((x, y))
            if y == 17:
                if (x + w, y) not in visited and (x + w, y) in grid:       
                    choice = "right"
            else:
                if x == 850:
                    choice = "up"
                else:
                    cell = ["up", "right"]
                    choice = random.choice(cell)   
            if choice == "right":
                push_right(x, y, maze_color)                                   
                solution[(x + w, y)] = x, y
                if (x, y) not in G:
                    G[(x, y)] = []
                if (x+w, y) not in G:
                    G[(x+w, y)] = []
                G[(x, y)].append((x+w, y))
                G[(x+w, y)].append((x, y))
            else:
                x, y = random.choice(visited)
                single_cell(x, y, GREEN)
                time.sleep(0.01)
                single_cell(x, y, maze_color)
                push_up(x, y, maze_color)
                solution[(x , y)] = x, y - w
                if (x, y) not in G:
                    G[(x, y)] = []
                if (x, y-w) not in G:
                    G[(x, y-w)] = []
                G[(x, y)].append((x, y-w))
                G[(x, y - w)].append((x, y))
                visited = []


def carve_out_maze_6(x, y, maze_color):
    single_cell(x, y, GREEN)
    visited = []
    w = 17                                     
    while len(visited) <= len(grid):
        lst = [(i, j) for i in range(17, 851, 17) for j in range(17, 511, 17) if (i, j) not in visited]
        x, y = random.choice(lst)
        # if (x, y) not in G:
        #     G[(x, y)] = []                                           
        time.sleep(0.01)
        # x, y = random.choice(lst)
        check = False
        temp = []
        stack = []
        while check == False:
            cell = []
            # temp = []
            # stack = []
            time.sleep(0.7)
            if  (x + w, y) in visited or (x - w, y)  in visited or (x , y + w)  in visited or (x, y - w) in visited:
                check = True
                continue
            if (x + w, y) in grid and (x + w, y) not in temp :       
                cell.append("right")                                   

            if (x - w, y) in grid and (x - w, y) not in temp: 
                cell.append("left")

            if (x , y + w) in grid and (x , y + w) not in temp:     
                cell.append("down")

            if (x , y - w) in grid and (x , y - w) not in temp:      
                cell.append("up")

            if len(cell) > 0:                                          
                cell_chosen = (random.choice(cell))                    

                if cell_chosen == "right":                             
                    push_right(x, y, maze_color)                                   
                    # solution[(x + w, y)] = x, y                        
                    x = x + w                                          
                    # visited.append((x, y))                              
                    stack.append((x, y))
                    temp.append((x, y))                                

                elif cell_chosen == "left":
                    push_left(x, y, maze_color)
                    # solution[(x - w, y)] = x, y
                    x = x - w
                    # visited.append((x, y))
                    stack.append((x, y))
                    temp.append((x, y))

                elif cell_chosen == "down":
                    push_down(x, y, maze_color)
                    # solution[(x , y + w)] = x, y
                
                    y = y + w
                    # visited.append((x, y))
                    stack.append((x, y))
                    temp.append((x, y))

                elif cell_chosen == "up":
                    push_up(x, y, maze_color)
                    # solution[(x , y - w)] = x, y
                    y = y - w
                    # visited.append((x, y))
                    stack.append((x, y))
                    temp.append((x, y))
            else:
                x, y = stack.pop()
                print(2)                                   
                single_cell(x, y, GREEN)                                     
                time.sleep(.01)                                       
                backtracking_cell(x, y, BLACK) 

def plot_route_back(x,y):
    solution_cell(x, y)                                         
    while (x, y) != (17,17):                                  
        x, y = solution[x, y]                                   
        solution_cell(x, y)                                    
        time.sleep(.04)
    return 

def plot_route_back_1(x,y):
    solution_cell(x, y)
    visited = []                                     
    while (x, y) != (17,17):
        visited.append((x, y))
        if (x, y) not in solution:
            while True:
                x += 17
                if solution[x, y] == (x, y-17):
                    break
        x, y = solution[x, y]                              
        solution_cell(x, y)                                    
        time.sleep(.1)
    return 


def display_victory():
    screen.fill(SCREEN)
    large_text = pygame.font.Font("freesansbold.ttf", 80)
    text_surf, text_rect = text_object("YOU WON!", large_text)
    text_rect.center = ((WIDTH / 2), (HEIGHT / 2))
    screen.blit(text_surf, text_rect)
    pygame.display.update()
    time.sleep(10)





def text_object(text, font):
    text_surf = font.render(text, True, BLACK)
    return text_surf, text_surf.get_rect()
 
# game_intro()

def RECURSIVE_BACKTRACKER_1(check, flag):
    running = True
    check = False
    present = ""
    minutes = 0
    seconds = 0
    while running:
        choice = ""
        # keep running at the at the right speed
        clock.tick(FPS)
        flag2 = False
        # process input (events)
        for event in pygame.event.get():
            # check for closing the window
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    plot_route_back(850,510)
                    screen.fill(BLACK)
                    running = False
                if event.key == pygame.K_RIGHT:
                    if (x + 17, y) in G[(x, y)]:
                        s, t = x, y
                        x += 17
                        pos.append((x, y, "left"))
                        choice = "right"
                if event.key == pygame.K_LEFT:
                    if (x - 17, y) in G[(x, y)]:
                        s, t = x, y
                        x -= 17
                        pos.append((x, y, "right"))
                        choice = "left"
                if event.key == pygame.K_UP:
                    if (x, y - 17) in G[(x, y)]:
                        s, t = x, y 
                        y -= 17
                        pos.append((x, y, "down"))
                        choice = "up"
                if event.key == pygame.K_DOWN:
                    if (x, y + 17) in G[(x, y)]:
                        s, t = x, y
                        y += 17
                        pos.append((x, y, "up"))
                        choice = "down"
                if event.key == pygame.K_BACKSPACE:
                    while len(G[(x, y)]) < 2 and (x >= 17 and y >= 17):
                        if len(pos) <= 0:
                            flag2 = True
                            break
                        else:
                            (x, y) = (pos[-1][0], pos[-1][1])
                            a, b, c = pos.pop()
                            if c == "up":
                                push_up(a, b, maze_color)
                            elif c == "right":
                                push_right(a, b, maze_color)
                            elif c == "down":
                                push_down(a, b, maze_color)
                            elif c == "left":
                                push_left(a, b, maze_color)
                                
                    if not flag2:
                        a, b, c = pos.pop()
                        if c == "up":
                                push_up(a, b, maze_color)
                        elif c == "right":
                            push_right(a, b, maze_color)
                        elif c == "down":
                            push_down(a, b, maze_color)
                        elif c == "left":
                            push_left(a, b, maze_color)
                        (x, y) = (pos[-1][0], pos[-1][1])

            if event.type == pygame.KEYUP:
                if event.key == pygame.K_LEFT or event.key == pygame.K_RIGHT or event.key == pygame.K_UP or event.key == pygame.K_DOWN:
                    x_change = 0; y_change = 0
        mouse = pygame.mouse.get_pos()
        click = pygame.mouse.get_pressed()
        if 980 + 300 > mouse[0] > 980 and 600 + 50 > mouse[1] > 600:
                pygame.draw.rect(screen, BLUE, (980, 600, 300, 50)) #(x, y, width, height)
                if click[0] == 1:
                    break
                    
        else:
            pygame.draw.rect(screen, BRIGHT_BLUE, (980, 600, 300, 50))
        
        small_text5 = pygame.font.Font("freesansbold.ttf", 20)
        text_surf, text_rect = text_object("MAIN MENU", small_text5)
        text_rect.center = ((980+(300/2)), (600+(50/2)))
        screen.blit(text_surf, text_rect)
        if check:

            display_girl(1100, 300, teacher)
            display_arrow(920, 300, arrow) 
            display_thought(1200, 185, thought)
            if 980 + 300 > mouse[0] > 980 and 500 + 50 > mouse[1] > 500:
                pygame.draw.rect(screen, RED, (980, 500, 300, 50)) #(x, y, width, height)
                if click[0] == 1:
                    backtracking_cell(17, 17, RED)
                    flag = True
                    check = False
                    
            else:
                pygame.draw.rect(screen, BRIGHT_RED, (980, 500, 300, 50))

            if 980 + 300 > mouse[0] > 980 and 600 + 50 > mouse[1] > 600:
                pygame.draw.rect(screen, BLUE, (980, 600, 300, 50)) #(x, y, width, height)
                if click[0] == 1:
                    break
                    
            else:
                pygame.draw.rect(screen, BRIGHT_BLUE, (980, 600, 300, 50))

            small_text4 = pygame.font.Font("freesansbold.ttf", 20)
            text_surf, text_rect = text_object("PLAY GAME", small_text4)
            text_rect.center = ((980+(300/2)), (500+(50/2)))
            screen.blit(text_surf, text_rect)
            

            small_text5 = pygame.font.Font("freesansbold.ttf", 20)
            text_surf, text_rect = text_object("MAIN MENU", small_text5)
            text_rect.center = ((980+(300/2)), (600+(50/2)))
            screen.blit(text_surf, text_rect)

            pygame.display.update()

        if flag:
            # ghari = ""

            # display_time(seconds, minutes, ghari, 1000, 100)
            # seconds += 1
            # if seconds > 59:
            #     minutes += 1
            #     seconds = 0
            # time.sleep(1.0)
            if not choice:
                continue
            present = choice
            if choice == "right":
                push_right(s, t, RED)
            elif choice == "left":
                push_left(s, t, RED)
            elif choice == "up":
                push_up(s, t, RED)
            elif choice == "down":
                push_down(s, t, RED)
            if (x, y) == (850, 510):
                time.sleep(2)
                plot_route_back(850, 510)
                display_victory()
                break
            
            # backtracking_cell(x, y, RED)
        if not flag and not check:
            screen.fill(BLACK)
            x, y = 17, 17                     
            build_grid_1(17, 0, 17)            
            carve_out_maze_1(x,y, maze_color)
            time.sleep(1.0)
            # plot_route_back(850,510)
            x, y = 17, 17
            check = True
            continue
         

def HUNT_AND_KILL_ALGORITHM(check, flag):
    running = True
    check = False
    present = ""
    minutes = 0
    seconds = 0
    while running:
        choice = ""
        # keep running at the at the right speed
        clock.tick(FPS)
        flag2 = False
        # process input (events)
        for event in pygame.event.get():
            # check for closing the window
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    plot_route_back(850,510)
                    screen.fill(BLACK)
                    running = False
                if event.key == pygame.K_RIGHT:
                    if (x + 17, y) in G[(x, y)]:
                        s, t = x, y
                        x += 17
                        pos.append((x, y, "left"))
                        choice = "right"
                if event.key == pygame.K_LEFT:
                    if (x - 17, y) in G[(x, y)]:
                        s, t = x, y
                        x -= 17
                        pos.append((x, y, "right"))
                        choice = "left"
                if event.key == pygame.K_UP:
                    if (x, y - 17) in G[(x, y)]:
                        s, t = x, y 
                        y -= 17
                        pos.append((x, y, "down"))
                        choice = "up"
                if event.key == pygame.K_DOWN:
                    if (x, y + 17) in G[(x, y)]:
                        s, t = x, y
                        y += 17
                        pos.append((x, y, "up"))
                        choice = "down"
                if event.key == pygame.K_BACKSPACE:
                    while len(G[(x, y)]) < 2 and (x >= 17 and y >= 17):
                        if len(pos) <= 0:
                            flag2 = True
                            break
                        else:
                            (x, y) = (pos[-1][0], pos[-1][1])
                            a, b, c = pos.pop()
                            if c == "up":
                                push_up(a, b, maze_color)
                            elif c == "right":
                                push_right(a, b, maze_color)
                            elif c == "down":
                                push_down(a, b, maze_color)
                            elif c == "left":
                                push_left(a, b, maze_color)
                                
                    if not flag2:
                        a, b, c = pos.pop()
                        if c == "up":
                                push_up(a, b, maze_color)
                        elif c == "right":
                            push_right(a, b, maze_color)
                        elif c == "down":
                            push_down(a, b, maze_color)
                        elif c == "left":
                            push_left(a, b, maze_color)
                        (x, y) = (pos[-1][0], pos[-1][1])

            if event.type == pygame.KEYUP:
                if event.key == pygame.K_LEFT or event.key == pygame.K_RIGHT or event.key == pygame.K_UP or event.key == pygame.K_DOWN:
                    x_change = 0; y_change = 0
        mouse = pygame.mouse.get_pos()
        click = pygame.mouse.get_pressed()
        if 980 + 300 > mouse[0] > 980 and 600 + 50 > mouse[1] > 600:
                pygame.draw.rect(screen, BLUE, (980, 600, 300, 50)) #(x, y, width, height)
                if click[0] == 1:
                    break
                    
        else:
            pygame.draw.rect(screen, BRIGHT_BLUE, (980, 600, 300, 50))
        
        small_text5 = pygame.font.Font("freesansbold.ttf", 20)
        text_surf, text_rect = text_object("MAIN MENU", small_text5)
        text_rect.center = ((980+(300/2)), (600+(50/2)))
        screen.blit(text_surf, text_rect)
        if check:

            display_girl(1100, 300, teacher)
            display_arrow(920, 300, arrow) 
            display_thought(1200, 185, thought)
            if 980 + 300 > mouse[0] > 980 and 500 + 50 > mouse[1] > 500:
                pygame.draw.rect(screen, RED, (980, 500, 300, 50)) #(x, y, width, height)
                if click[0] == 1:
                    backtracking_cell(17, 17, RED)
                    flag = True
                    check = False
                    
            else:
                pygame.draw.rect(screen, BRIGHT_RED, (980, 500, 300, 50))

            if 980 + 300 > mouse[0] > 980 and 600 + 50 > mouse[1] > 600:
                pygame.draw.rect(screen, BLUE, (980, 600, 300, 50)) #(x, y, width, height)
                if click[0] == 1:
                    break
                    
            else:
                pygame.draw.rect(screen, BRIGHT_BLUE, (980, 600, 300, 50))

            small_text4 = pygame.font.Font("freesansbold.ttf", 20)
            text_surf, text_rect = text_object("PLAY GAME", small_text4)
            text_rect.center = ((980+(300/2)), (500+(50/2)))
            screen.blit(text_surf, text_rect)
            

            small_text5 = pygame.font.Font("freesansbold.ttf", 20)
            text_surf, text_rect = text_object("MAIN MENU", small_text5)
            text_rect.center = ((980+(300/2)), (600+(50/2)))
            screen.blit(text_surf, text_rect)

            pygame.display.update()

        if flag:
            # ghari = ""

            # display_time(seconds, minutes, ghari, 1000, 100)
            # seconds += 1
            # if seconds > 59:
            #     minutes += 1
            #     seconds = 0
            # time.sleep(1.0)
            if not choice:
                continue
            present = choice
            if choice == "right":
                push_right(s, t, RED)
            elif choice == "left":
                push_left(s, t, RED)
            elif choice == "up":
                push_up(s, t, RED)
            elif choice == "down":
                push_down(s, t, RED)
            if (x, y) == (850, 510):
                time.sleep(2)
                plot_route_back(850, 510)
                display_victory()
                break
            # backtracking_cell(x, y, RED)
        if not flag and not check:
                
            screen.fill(BLACK)
            x, y = 17, 17                     
            build_grid_1(17, 0, 17)            
            carve_out_maze_3(x,y, maze_color)              
            # plot_route_back(850,510)
            check = True
            continue
            # break      


def PRIM_ALGORITHM(check, flag):
    running = True
    check = False
    present = ""
    minutes = 0
    seconds = 0
    while running:
        choice = ""
        # keep running at the at the right speed
        clock.tick(FPS)
        flag2 = False
        # process input (events)
        for event in pygame.event.get():
            # check for closing the window
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    plot_route_back(850,510)
                    screen.fill(BLACK)
                    running = False
                if event.key == pygame.K_RIGHT:
                    if (x + 17, y) in G_1[(x, y)]:
                        s, t = x, y
                        x += 17
                        pos.append((x, y, "left"))
                        choice = "right"
                if event.key == pygame.K_LEFT:
                    if (x - 17, y) in G_1[(x, y)]:
                        s, t = x, y
                        x -= 17
                        pos.append((x, y, "right"))
                        choice = "left"
                if event.key == pygame.K_UP:
                    if (x, y - 17) in G_1[(x, y)]:
                        s, t = x, y 
                        y -= 17
                        pos.append((x, y, "down"))
                        choice = "up"
                if event.key == pygame.K_DOWN:
                    if (x, y + 17) in G_1[(x, y)]:
                        s, t = x, y
                        y += 17
                        pos.append((x, y, "up"))
                        choice = "down"
                if event.key == pygame.K_BACKSPACE:
                    while len(G_1[(x, y)]) < 2 and (x >= 17 and y >= 17):
                        if len(pos) <= 0:
                            flag2 = True
                            break
                        else:
                            (x, y) = (pos[-1][0], pos[-1][1])
                            a, b, c = pos.pop()
                            if c == "up":
                                push_up(a, b, maze_color)
                            elif c == "right":
                                push_right(a, b, maze_color)
                            elif c == "down":
                                push_down(a, b, maze_color)
                            elif c == "left":
                                push_left(a, b, maze_color)
                                
                    if not flag2:
                        a, b, c = pos.pop()
                        if c == "up":
                                push_up(a, b, maze_color)
                        elif c == "right":
                            push_right(a, b, maze_color)
                        elif c == "down":
                            push_down(a, b, maze_color)
                        elif c == "left":
                            push_left(a, b, maze_color)
                        (x, y) = (pos[-1][0], pos[-1][1])

            if event.type == pygame.KEYUP:
                if event.key == pygame.K_LEFT or event.key == pygame.K_RIGHT or event.key == pygame.K_UP or event.key == pygame.K_DOWN:
                    x_change = 0; y_change = 0
        mouse = pygame.mouse.get_pos()
        click = pygame.mouse.get_pressed()
        if 980 + 300 > mouse[0] > 980 and 600 + 50 > mouse[1] > 600:
                pygame.draw.rect(screen, BLUE, (980, 600, 300, 50)) #(x, y, width, height)
                if click[0] == 1:
                    break
                    
        else:
            pygame.draw.rect(screen, BRIGHT_BLUE, (980, 600, 300, 50))
        
        small_text5 = pygame.font.Font("freesansbold.ttf", 20)
        text_surf, text_rect = text_object("MAIN MENU", small_text5)
        text_rect.center = ((980+(300/2)), (600+(50/2)))
        screen.blit(text_surf, text_rect)
        if check:

            display_girl(1100, 300, teacher)
            display_arrow(920, 300, arrow) 
            display_thought(1200, 185, thought)
            if 980 + 300 > mouse[0] > 980 and 500 + 50 > mouse[1] > 500:
                pygame.draw.rect(screen, RED, (980, 500, 300, 50)) #(x, y, width, height)
                if click[0] == 1:
                    backtracking_cell(17, 17, RED)
                    flag = True
                    check = False
                    
            else:
                pygame.draw.rect(screen, BRIGHT_RED, (980, 500, 300, 50))

            if 980 + 300 > mouse[0] > 980 and 600 + 50 > mouse[1] > 600:
                pygame.draw.rect(screen, BLUE, (980, 600, 300, 50)) #(x, y, width, height)
                if click[0] == 1:
                    break
                    
            else:
                pygame.draw.rect(screen, BRIGHT_BLUE, (980, 600, 300, 50))

            small_text4 = pygame.font.Font("freesansbold.ttf", 20)
            text_surf, text_rect = text_object("PLAY GAME", small_text4)
            text_rect.center = ((980+(300/2)), (500+(50/2)))
            screen.blit(text_surf, text_rect)
            

            small_text5 = pygame.font.Font("freesansbold.ttf", 20)
            text_surf, text_rect = text_object("MAIN MENU", small_text5)
            text_rect.center = ((980+(300/2)), (600+(50/2)))
            screen.blit(text_surf, text_rect)

            pygame.display.update()

        if flag:
            # ghari = ""

            # display_time(seconds, minutes, ghari, 1000, 100)
            # seconds += 1
            # if seconds > 59:
            #     minutes += 1
            #     seconds = 0
            # time.sleep(1.0)
            if not choice:
                continue
            present = choice
            if choice == "right":
                push_right(s, t, RED)
            elif choice == "left":
                push_left(s, t, RED)
            elif choice == "up":
                push_up(s, t, RED)
            elif choice == "down":
                push_down(s, t, RED)
            if (x, y) == (850, 510):
                time.sleep(2)
                plot_route_back(850, 510)
                display_victory()
                break
            # backtracking_cell(x, y, RED)
        if not flag and not check:
            screen.fill(BLACK)
            pygame.display.update()
            # for i in range(20, 401, 20):
            # for j in range(20, 401, 20):
            #     x, y = i, j
            lst = [(i, j)for i in range(17, 851, 17) for j in range(17, 511, 17)]
            x, y = random.choice(lst)                    
            build_grid_2(17, 0, 17)
            carve_out_maze_2(x,y,stack, maze_color)
            x, y = 17, 17
            # display_player(player, 20, 20)
            # plot_route_back(850,510)
            pygame.display.update()
            check = True
            continue
            
    
def KRUSKAL_ALGORITHM():
    running = True
    while running:
        clock.tick(FPS)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
        screen.fill(BLACK)
        
        pygame.display.update()
        lst = [(i, j)for i in range(17, 851, 17) for j in range(17, 511, 17)]
        x, y = random.choice(lst)                     
        build_grid_4(17, 0, 17)
        carve_out_maze_4(x,y,edges, grid, maze_color)
        plot_route_back(850, 510)
        break
        
def SIDEWINDER_ALGORITHM():
    running = True
    while running:
        clock.tick(FPS)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
        screen.fill(BLACK)
        pygame.display.update()
        x, y = 17, 17
        build_grid_1(17, 0, 17)
        carve_out_maze_5(x, y, maze_color)
        plot_route_back_1(850, 510)
        break

def WILSON_ALGORITHM():
    running = True
    while running:
        clock.tick(FPS)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
        screen.fill(BLACK)
        pygame.display.update()
        lst = [(i, j)for i in range(17, 851, 17) for j in range(17, 511, 17)]
        x, y = random.choice(lst)    
        build_grid_1(17, 0, 17)
        carve_out_maze_6(x, y, maze_color)
        plot_route_back_1(850, 510)
        break



        
def game_intro():
    intro = True
    num = 0
    while intro:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                intro = False
        
        screen.fill(SCREEN)
        display_tree(985, (HEIGHT / 2) - 100 , tree)
        large_text = pygame.font.Font("freesansbold.ttf", 60)
        text_surf, text_rect = text_object("MAZE GENERATOR", large_text)
        text_rect.center = ((WIDTH / 2), 50)
        screen.blit(text_surf, text_rect)

        # if not num % 2:
        #     mixer.music.load("journey.wav")
        #     mixer.music.play(-1)      
        mouse = pygame.mouse.get_pos()
        click = pygame.mouse.get_pressed()
        # pygame.draw.rect(screen, BRIGHT_ORANGE, (1230, 45, 100, 90))
        display_maze(maze, (WIDTH/2) - 50,130)
        

        if 1230 + 100> mouse[0] > 1230 and 45 + 90 > mouse[1] > 45:
            pygame.draw.rect(screen, BLUE, (1230, 45, 100, 90)) #(x, y, width, height)
            if click[0] == 1:
                num += 1  
        else:
            pygame.draw.rect(screen, BRIGHT_BLUE, (1230, 45, 100, 90)) #(x, y, width, height)
        display_volume(1250, 60, volume)
        if 17 + 478 > mouse[0] > 17 and 300 + 50 > mouse[1] > 300:
            pygame.draw.rect(screen, BLUE, (17, 300, 478, 50)) #(x, y, width, height)
            if click[0] == 1:
                RECURSIVE_BACKTRACKER_1(False, False)
                renew()
        else:
            pygame.draw.rect(screen, BRIGHT_BLUE, (17, 300, 478, 50)) #(x, y, width, height)


        if 535 + 270 > mouse[0] > 535 and 300 + 50 > mouse[1] > 300:
            pygame.draw.rect(screen, RED, (535, 300, 270, 50)) #(x, y, width, height)
            if click[0] == 1:
                PRIM_ALGORITHM(False, False)
        else:
            pygame.draw.rect(screen, BRIGHT_RED, (535, 300, 270, 50)) #(x, y, width, height)
        
        if 17 + 478 > mouse[0] > 17 and 400 + 50 > mouse[1] > 400:
            pygame.draw.rect(screen, YELLOW, (17, 400, 478, 50)) #(x, y, width, height)
            if click[0] == 1:
                
                HUNT_AND_KILL_ALGORITHM(False, False)
        else:
            pygame.draw.rect(screen, BRIGHT_YELLOW, (17, 400, 478, 50)) #(x, y, width, height)
        
        if 535 + 270 > mouse[0] > 535 and 400 + 50 > mouse[1] > 400:
            pygame.draw.rect(screen, PINK, (535, 400, 270, 50)) #(x, y, width, height)
            if click[0] == 1:
                KRUSKAL_ALGORITHM()
        else:
            pygame.draw.rect(screen, BRIGHT_PINK, (535, 400, 270, 50)) #(x, y, width, height)
        if 17 + 478 > mouse[0] > 17 and 500 + 50 > mouse[1] > 500:
            pygame.draw.rect(screen, PURPLE, (17, 500, 478, 50)) #(x, y, width, height)
            if click[0] == 1:
                
                SIDEWINDER_ALGORITHM()
        else:
            pygame.draw.rect(screen, BRIGHT_PURPLE, (17, 500, 478, 50)) #(x, y, width, height)
        if 535 + 270 > mouse[0] > 535 and 500 + 50 > mouse[1] > 500:
            pygame.draw.rect(screen, ORANGE, (535, 500, 270, 50)) #(x, y, width, height)
            if click[0] == 1:
                WILSON_ALGORITHM()
        else:
            pygame.draw.rect(screen, BRIGHT_ORANGE, (535, 500, 270, 50)) #(x, y, width, height)

        small_text1 = pygame.font.Font("freesansbold.ttf", 20)
        text_surf, text_rect = text_object("RECURSIVE BACKTRACKING ALGORITHM (DFS)", small_text1)
        text_rect.center = ((180+(150/2)), (300+(50/2)))
        screen.blit(text_surf, text_rect)
        

        small_text2 = pygame.font.Font("freesansbold.ttf", 20)
        text_surf, text_rect = text_object("PRIM'S ALGORITHM", small_text2)
        text_rect.center = ((535+(270/2)), (300+(50/2)))
        screen.blit(text_surf, text_rect)
        

        small_text3 = pygame.font.Font("freesansbold.ttf", 20)
        text_surf, text_rect = text_object("HUNT AND KILL ALGORITHM", small_text3)
        text_rect.center = ((180+(150/2)), (400+(50/2)))
        screen.blit(text_surf, text_rect)


        small_text4 = pygame.font.Font("freesansbold.ttf", 20)
        text_surf, text_rect = text_object("KRUSKAL'S ALGORITHM", small_text4)
        text_rect.center = ((535+(270/2)), (400+(50/2)))
        screen.blit(text_surf, text_rect)
        

        small_text3 = pygame.font.Font("freesansbold.ttf", 20)
        text_surf, text_rect = text_object("SIDEWINDER ALGORITHM", small_text3)
        text_rect.center = ((180+(150/2)), (500+(50/2)))
        screen.blit(text_surf, text_rect)

        small_text4 = pygame.font.Font("freesansbold.ttf", 20)
        text_surf, text_rect = text_object("WILSON'S ALGORITHM", small_text4)
        text_rect.center = ((535+(270/2)), (500+(50/2)))
        screen.blit(text_surf, text_rect)

        pygame.display.update()
        # clock.tick(15)
game_intro()
# ##### pygame loop #######
# entered()
pygame.quit()
# quit()
        
                
# - Recursive backtracking algorithm
# - Hunt and kill algorithm
# - Eller's algorithm
# - Sidewinder algorithm
# - Prim's algorithm
# - Kruskal's algorithm
# - Depth-first search
# - Breadth-first search (not shown in video)
